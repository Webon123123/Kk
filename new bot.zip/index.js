const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const path = require('path');
const readline = require('readline');
const chalk = require('chalk');
const handler = require('./handler');

const sessionPath = path.join(__dirname, 'Sesion');
const logger = pino({ level: 'silent' });

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const question = (text) => new Promise((resolve) => rl.question(text, resolve));
const minReconnectDelay = 10000;
const maxReconnectDelay = 30000;

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        browser: Browsers.ubuntu('Opera'),
        logger,
    });    

    sock.ev.on('creds.update', saveCreds);  

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;        
        
        if (connection === 'connecting') {
            console.log(chalk.black.bgYellowBright(' 🍀. Iniciando la conexión . . . '));
        } else if (connection === 'open') {
            console.log(chalk.white.bgGreen(' ✅. ¡Se estableció correctamente la sesión con el WhatsApp! '));
            if (rl) rl.close();
        } else if (connection === 'close') {
            const statusCode = new Boom(lastDisconnect.error)?.output?.statusCode;
            if (statusCode === DisconnectReason.loggedOut) {
                console.log(chalk.white.bgRed(' 🔒. Conexión perdida: credenciales no válidas. Borre la carpeta de sesión y vuelva a vincular. '));
                process.exit(1);
            } else {
                const reconnectDelay = Math.floor(Math.random() * (maxReconnectDelay - minReconnectDelay + 1)) + minReconnectDelay;
                console.log(chalk.black.bgCyan(` 🔄. Conexión perdida. Reintentando en ${reconnectDelay / 1000} segundos... `));
                setTimeout(connectToWhatsApp, reconnectDelay);
            }
        }
    });
    
    if (process.stdin.isTTY && !sock.authState.creds.registered) {
        console.log(chalk.black.bgYellow(' 🌳. No se encontró una sesión activa. '));
        const phoneNumber = await question(chalk.green(' 🌴 Introduce el número de teléfono: '));
        const pairingCode = await sock.requestPairingCode(phoneNumber.trim());
        console.log(chalk.white.bgBlue(` 🌷. Código de emparejamiento: ${pairingCode} `));
    }
    
    sock.ev.on('messages.upsert', async (mek) => {
        try {
            const m = mek.messages[0];
            if (!m.message || m.key.remoteJid === 'status@broadcast') return;
            await handler(sock, m);
        } catch (e) {
            console.error(chalk.white.bgRed('🌾. Error al manejar mensaje : '), e);
        }
    });
    
    return sock;
}

connectToWhatsApp().catch((err) => {
    console.error(chalk.white.bgRed('🌹. Error al iniciar el bot : '), err);
});