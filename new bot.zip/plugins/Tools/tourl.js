const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { uploadToImgbb } = require('../../lib/functions');

module.exports = {
    command: 'tourl',
    description: 'Convertir archivos multimedia de imagen o vídeo a URL.',
    run: async (sock, message, args) =>  {
        let mediaSource = null;
        const quotedMessage = message.msg?.contextInfo?.quotedMessage;

        if (quotedMessage && /imageMessage|videoMessage/.test(Object.keys(quotedMessage)[0])) {
            mediaSource = { message: quotedMessage };
        
        } else if (/imageMessage|videoMessage/.test(message.type)) {
            mediaSource = message;
        } else {
            return message.reply('🏝️. Por favor, responda con una imagen/vídeo, o envíe una imagen/vídeo con el texto `.turl`');
        }

        try {
            await message.reply('_Espera un momento . . ._);
            const buffer = await downloadMediaMessage(mediaSource, 'buffer', {});
            const url = await uploadToImgbb(buffer);
            await message.reply(url);
        } catch (e) {
            console.error(e);
            await message.reply(`Error al cargar el archivo multimedia. Error : ${e.message}`);
        }
    }
};