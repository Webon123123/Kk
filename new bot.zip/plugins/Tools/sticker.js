const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
    command: 's',
    description: 'Crea stickers a partir de imágenes/videos.',
    run: async (sock, message, args) =>  {
        let mediaSource = null;
        const quotedMessage = message.msg?.contextInfo?.quotedMessage;

        if (quotedMessage && /imageMessage|videoMessage/.test(Object.keys(quotedMessage)[0])) {
            mediaSource = { message: quotedMessage };
        } else if (/imageMessage|videoMessage/.test(message.type)) {
            mediaSource = message;
        } else {
            return message.reply('🌱. Por favor, responda con una imagen/vídeo, o envíe una imagen/vídeo con el texto `.s`');
        }

        try {
            await message.reply('_Espera un momento . . ._');
            const buffer = await downloadMediaMessage(mediaSource, 'buffer', {});
            await message.sticker(buffer);
        } catch (e) {
            console.error(e);
            await message.reply(`No se pudo crear el sticker. Asegúrese de que respondió a una imagen / vídeo.\nError : ${e.message}`);
        }
    }
};