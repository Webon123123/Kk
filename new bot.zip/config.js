module.exports = {
    prefix: '.',
    ownerNumber: '5212431268546',
    ownerName: "I'm Fz ~",
    botName: "ѕуℓρнιєттє'ѕ | αℓρнα ν2",
    isPublic: false,
    autoRead: true,
    autoTyping: true
};