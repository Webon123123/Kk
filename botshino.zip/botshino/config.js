module.exports = {
    prefix: '.',
    ownerNumber: '5491125933603',
    ownerName: "Masha",
    botName: "HoshinoV2| Ai hoshino",
    isPublic: false,
    autoRead: true,
    autoTyping: true
};