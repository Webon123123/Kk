<h1 align="center">‧ 【 ✯ Ai Hoshino - MD ✰ 】 ‧
</p>
<p>
        <img src= "https://telegra.ph/file/89fa6a3c8e9cedda6f5ca.jpg">
    </p>
    <p align="center">
        <a href="#"><img title="simple-whatsapp-bot" src="https://img.shields.io/badge/-SIMPLE--WHATSAPP--BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
    </p>
    <p>
        <a href="https://github.com/Webon123123/Ai-hoshino-bot-whatssap-"><img title="Author" src="https://img.shields.io/badge/Author-masha_ofc-purple.svg?style=for-the-badge&logo=github"></a>
    </p>
    <p>
        <a href="https://github.com/Webon123123/Ai-hoshino-bot-whatssap-/followers"><img title="Followers" src="https://img.shields.io/github/followers/Webon123123?color=blue&style=flat-square"></a>
        <a href="https://github.com/Webon123123/Ai-hoshino-bot-whatssap-/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Webon123123/Ai-hoshino-bot-whatssap-?color=red&style=flat-square"></a>
        <a href="https://github.com/Webon123123/Ai-hoshino-bot-whatssap-/network/members"><img title="Forks" src="http://img.shields.io/github/forks/Webon123123/Ai-hoshino-bot-whatssap-?color=red&style=flat-square"></a>
        <a href="#"><img src="https://img.shields.io/badge/MANTENIMIENTO-SI-blue.svg"></a>
        <img src="https://img.shields.io/github/repo-size/Webon123123/Ai-hoshino-bot-whatssap-" /> <br>
   </p>
   <p>
</h1>

---------

### ⭐ Activa En Joan-TK Host

<a href="dash.tk-joanhost.com"><img src="https://images.app.goo.gl/tgH49FVqvvNEyTsY7" width="300" height="300" alt="Tk Host"/></a>

- Dash: [dash.tk-joanhost.com](dash.tk-joanhost.com/login)
- Panel: [panel.tk-joanhost.com](https://panel.tk-joanhost.com)
- Canal de WhatsApp: [【 ✯ Starlights Team - Oficial Chanel ✰ 】](https://whatsapp.com/channel/0029Vak9Hmd1iUxdfDUdCK1w)

[![Click Aquí](https://img.shields.io/badge/Soporte-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/595976230899)

---------

## <img src="https://i.pinimg.com/originals/73/69/6e/73696e022df7cd5cb3d999c6875361dd.gif" alt="Características" width="42" height="42"> Características

> Bot en creación pronto se agregaran más cosas 

- [x] Interacción con voz y texto
- [x] Configuración de grupo
- [x] antidelete, antilink, antiarabes, etc
- [x] Bienvenida personalizada
- [x] Chatbot (simsimi)
- [x] Crear sticker de image/video/gif/url
- [x] SubBot (Jadibot)
- [x] Juego RPG
- [x] Descarga de música y video de YT
- [ ] Otros

---------

## <img src="https://i.pinimg.com/originals/19/80/6e/19806e91932e6054965fc83b85241270.gif" alt="Contacto" width="42" height="42"> Contacto

- Si la Bot tiene algún contactame ฅ^•ﻌ•^ฅ

* <a href="https://wa.me/595976230899"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## <img src="https://static.wikia.nocookie.net/nyancat/images/d/d3/Nyan-cat.gif/revision/latest/scale-to-width-down/400?cb=20131231222500&path-prefix=es" alt="Grupo" width="45" height="43"> Grupo de WhatsApp

- Si quieres probar la Bot antes de instalar

* <a href="wa.me/51953432204"><img alt="Group" src="https://img.shields.io/badge/Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## Repo Stats 🔭

![github card](https://github-readme-stats.vercel.app/api/pin/?username=Webon123123&repo=Ai-hoshino-bot-whatssap-&theme=chartreuse-dark)

---------

## <img src="https://raw.githubusercontent.com/vilcajoal/vilcajoal/master/assets/octocat-anime.gif" alt="Github" width="44" height="44"> Github Stats

![github stats](https://github-readme-stats.vercel.app/api?username=Webon123123&show_icons=true&theme=chartreuse-dark)
![github toplang](https://github-readme-stats.vercel.app/api/top-langs/?username=Webon123123&layout=compact&theme=chartreuse-dark)

---------
<div align="center">
  <h1 align="center">Editora y Propietaria de la Bot</h1>

<a href="https://atom.bio/masha_ofc"><img src="https://github.com/Webon123123.png" width="300" height="300" alt="masha_ofc"/></a>

`© Ai Hoshino - MD / Starlights Team _ By Masha_ofc`
