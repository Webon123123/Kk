import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import Esprima from 'esprima';
import JSHint from 'jshint';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return await m.reply(`「✦」Error: *No ingresaste ningún código para analizar.*\n\n> ✐ Usa el comando así:\n> *${usedPrefix + command}* <código>`);
  }

  const fileName = 'code.js';
  const filePath = path.join('/tmp', fileName);
  fs.writeFileSync(filePath, text);

  let errors = '';
  let lineNumber = 0;

  try {
    Esprima.parseScript(text);

    if (!JSHint.JSHINT(text)) {
      JSHint.JSHINT.errors.forEach((err) => {
        if (err) {
          errors += `🛑 Error en la línea ${err.line}:\n` +
                    `> ✐ *${err.reason}*\n` +
                    `> Posible solución: *Revisa el código en la línea ${err.line}.*\n\n`;
          lineNumber++;
        }
      });
    }

    let pluginErrors = detectPluginIssues(text);
    if (pluginErrors.length > 0) {
      pluginErrors.forEach((err) => {
        errors += `🛠️ Problema con Plugin:\n> ✐ ${err}\n\n`;
      });
    }

    const detailedAnalysis = analyzeCode(text);

    if (errors || detailedAnalysis) {
      await m.reply(`「✦」*Se encontraron problemas en tu código JavaScript:*\n\n${errors}${detailedAnalysis}`);
      await suggestFixes(m, errors + detailedAnalysis);
    } else {
      await m.reply('「✦」¡El código está libre de errores! 🎉');
    }

  } catch (error) {
    errors += `🛑 *Error en la estructura del código:*\n> ✐ *Detalles: ${error.message}*\n\n`;
    await m.reply(`「✦」*Errores detectados:*\n\n${errors}`);
  } finally {
    fs.unlinkSync(filePath);
  }
};

function detectPluginIssues(code) {
  let issues = [];

  if (/var\s+\w+[^=]/.test(code)) {
    issues.push('¡Advertencia! Usaste una variable no declarada sin asignación en tu código. Asegúrate de inicializarla correctamente.');
  }

  if (/function\s+\w+\s*[^)]*\s*{[^}]*}/.test(code) && !/return/.test(code)) {
    issues.push('¡Advertencia! Tienes una función sin un retorno definido. Esto puede causar errores inesperados en los plugins.');
  }

  if (/eval/.test(code)) {
    issues.push('⚠️ Uso de "eval()". Evita usar eval ya que puede generar conflictos con los plugins o problemas de seguridad.');
  }

  if (!/require\s*['"][\w-/]+['"]/.test(code) && /require/.test(code)) {
    issues.push('🚨 Problema con las dependencias: *Asegúrate de que las librerías estén correctamente configuradas o requeridas.*');
  }

  if (/\.then\s*/.test(code) && !/catch\s*/.test(code)) {
    issues.push('⚠️ Estás utilizando Promesas sin un manejo adecuado de errores (catch). Asegúrate de añadir .catch() para evitar problemas.');
  }

  if (/case\s+.*?:\s*(?!break;)/.test(code)) {
    issues.push('⚠️ Hay un "case" en tu switch que no incluye un "break". Esto puede generar errores en el flujo lógico.');
  }

  return issues;
}

function analyzeCode(code) {
  const lines = code.split('\n');
  let detailedErrors = '';
  lines.forEach((line, index) => {
    if (/let\s+\w+;/.test(line) || /const\s+\w+;/.test(line)) {
      detailedErrors += `🔍 Línea ${index + 1}: Declaración de variable sin asignación inicial. Considera asignarle un valor o usar "null".\n\n`;
    }

    if (/function\s+\w+/.test(line) && !line.includes('{')) {
      detailedErrors += `🔍 Línea ${index + 1}: Posible definición incompleta de función. Asegúrate de incluir el cuerpo de la función.\n\n`;
    }

    if (/case\s+.*?:\s*(?!break;)/.test(line)) {
      detailedErrors += `⚠️ Línea ${index + 1}: Hay un "case" sin un "break". Esto puede causar que los siguientes bloques también se ejecuten.\n\n`;
    }

    if (/conn\.[a-zA-Z]+/.test(line) && !/await/.test(line)) {
      detailedErrors += `⚠️ Línea ${index + 1}: Llamada a función de conexión sin "await". Esto puede causar errores si la operación es asincrónica.\n\n`;
    }
  });
  return detailedErrors;
}

async function suggestFixes(m, detailedErrors) {
  const suggestions = `「✦」*IA Solucionadora de Errores*\n\n` +
                      `✐ He analizado los errores detectados en tu código y te recomiendo lo siguiente:\n\n` +
                      `${detailedErrors.replace(/🔍/g, '✎').replace(/⚠️/g, '✐').replace(/🛑/g, '✘')}`;
  await m.reply(suggestions);
}

handler.help = ['iacode'];
handler.tags = ['utility'];
handler.command = ['iacode'];

export default handler;