import fetch from 'node-fetch';
import yts from 'yt-search';
import fs from 'fs';
import path from 'path';
import ffmpeg from 'fluent-ffmpeg'; 

let handler = async (m, { conn: star, command, args, text, usedPrefix }) => {
  if (!text) {
    let errorMsg = `「✦」Error: *No ingresaste un título.*\n\n> ✐ Por favor, ingresa el título de un video o canción.\n\nEjemplo:\n> *${usedPrefix + command}* Minecraft relax soundtrack`;
    return star.reply(m.chat, errorMsg, m, rcanal);
  }

  await m.react('⌛');

  try {
    let res = await yts.search({ query: args.join(" "), hl: "es", gl: "ES" });
    if (!res.videos || res.videos.length === 0) return star.reply(m.chat, '*✐ No se encontraron resultados para tu búsqueda.*', m, rcanal);

    let video = res.videos[0];
    let info = `「✦」*${command === 'playaudio' ? 'Audio' : 'Video'} de YouTube descargado*\n\n` +
               `> ✐ *Título:* ${video.title}\n` +
               `> ✐ *Canal:* ${video.author.name || 'Desconocido'}\n` +
               `> ✐ *Duración:* ${Math.floor(video.duration.seconds / 60)}m ${video.duration.seconds % 60}s\n` +
               `> ✐ *Calidad:* 132k\n` +
               `> ✐ *Tamaño estimado:* 0.62MB\n` +
               `> ✐ *Link:* https://youtu.be/${video.videoId}\n`;

    await star.sendMessage(m.chat, { image: { url: video.image }, caption: info }, { quoted: m });

    const downloadUrl = `https://api-rin-tohsaka.vercel.app/download/${command === 'playaudio' ? 'ytmp3' : 'ytmp4'}?url=https://youtu.be/${video.videoId}`;
    const response = await fetch(downloadUrl);

    if (!response.ok) {
      await m.react('✖️');
      return star.reply(m.chat, `Error, motivo: "La API devolvió un código HTTP ${response.status}"`, m);
    }

    const buffer = await response.buffer();
    const fileSize = parseInt(response.headers.get('content-length')) || buffer.length;

    if (fileSize > 50 * 1024 * 1024) {
      await m.react('✖️');
      return star.reply(m.chat, `「✦」Error: *El archivo supera el límite de 50 MB.*\n\nPor favor, intenta con otro archivo más pequeño.`, m, rcanal);
    }

    const filePath = path.join('/tmp', `${video.videoId}.${command === 'playaudio' ? 'mp3' : 'mp4'}`);
    fs.writeFileSync(filePath, buffer);

    if (!fs.existsSync(filePath)) {
      await m.react('✖️');
      return star.reply(m.chat, 'Error: No se pudo guardar el archivo correctamente.', m);
    }

    if (fs.statSync(filePath).size === 0) {
      await m.react('✖️');
      return star.reply(m.chat, 'Error: El archivo descargado está vacío.', m);
    }
    const convertedFilePath = path.join('/tmp', `${video.videoId}.opus`);
    if (command === 'playaudio') {
      await new Promise((resolve, reject) => {
        ffmpeg(filePath)
          .audioCodec('libopus')
          .toFormat('opus')
          .on('end', resolve)
          .on('error', reject)
          .save(convertedFilePath);
      });

      fs.unlinkSync(filePath); 
    }

    setTimeout(async () => {
      if (command === 'playaudio') {
        await star.sendMessage(
          m.chat,
          { audio: { url: convertedFilePath }, mimetype: 'audio/ogg; codecs=opus', ptt: false },
          { quoted: m }
        );
        fs.unlinkSync(convertedFilePath);
      } else {
        await star.sendMessage(
          m.chat,
          { video: { url: filePath }, mimetype: 'video/mp4' },
          { quoted: m }
        );
      }

      await m.react('✅');
    }, 1000); 

  } catch (error) {
    await m.react('✖️');
    await star.reply(m.chat, `Error, motivo: "${error.message}"`, m);
  }
};

handler.help = ['playaudio *<búsqueda>*', 'mp4 *<búsqueda>*'];
handler.tags = ['downloader'];
handler.command = ['playaudio', 'mp4'];

export default handler;