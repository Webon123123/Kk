import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let handler = async (m, { text, conn }) => {
    if (!text) {
        return m.reply('Por favor, especifica el nombre del plugin. Ejemplo: .leer test');
    }

    const pluginsDir = path.join(__dirname, './');
    const fileName = text.trim();
    const files = fs.readdirSync(pluginsDir);

    const foundFile = files.find(file => path.parse(file).name === fileName);

    if (!foundFile) {
        return m.reply(`No se encontró ningún plugin llamado "${fileName}".`);
    }

    
    const filePath = path.join(pluginsDir, foundFile);

    try {
        
        const fileContent = fs.readFileSync(filePath, 'utf-8');

  
        m.reply(`*Contenido del plugin "${fileName}":*\n\n${fileContent}`);
    } catch (err) {
        console.error(err);
        m.reply('Hubo un error al leer el archivo.');
    }
};

handler.command = /^leer|leerplug|checkp|checkplug|verplugin$/i; 
handler.help = ['leer <nombre>'];
handler.description = 'Lee el contenido de un plugin de la carpeta "plugins"';
handler.rowner = true
export default handler;