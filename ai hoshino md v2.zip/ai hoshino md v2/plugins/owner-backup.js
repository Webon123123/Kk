import fs from 'fs';
import path from 'path';
import archiver from 'archiver';

let handler = async (m, { conn: star }) => {
  try {
    let backupFolder = './';
    let archiveFileName = 'backup.archive';
    let archiveFilePath = path.join(backupFolder, archiveFileName);

    let output = fs.createWriteStream(archiveFilePath);
    let archive = archiver('zip', { zlib: { level: 9 } });

    await m.react('⌛');

    output.on('close', async () => {
      let zipSize = archive.pointer();
      let recipient = m.isGroup ? m.sender : m.chat;

      await star.sendMessage(
        recipient,
        {
          document: { url: archiveFilePath },
          fileName: archiveFileName,
          mimetype: 'application/zip',
          caption: `📦 *Backup realizado*\n\n> ✐ Tamaño: ${(zipSize / (1024 * 1024)).toFixed(2)} MB`,
        },
        { quoted: m }
      );

      if (m.isGroup) {
        await star.reply(m.chat, `Backup realizado. El archivo ha sido enviado en privado.`, m);
      }
      await m.react('✅');
    });

    archive.on('error', async (err) => {
      await m.react('✖️');
      throw new Error(`Error al crear el backup: ${err.message}`);
    });

    archive.pipe(output);

    const directoriesToBackup = [backupFolder, './plugins', './lib'];

    directoriesToBackup.forEach((dir) => {
      if (fs.existsSync(dir)) {
        fs.readdirSync(dir).forEach((file) => {
          let filePath = path.join(dir, file);
          if (!fs.lstatSync(filePath).isDirectory() && !file.endsWith('.archive')) {
            archive.file(filePath, { name: path.relative(backupFolder, filePath) });
          }
        });
      }
    });

    archive.finalize();
  } catch (error) {
    await m.react('✖️');
    await star.reply(m.chat, `Error al realizar el backup: "${error.message}"`, m);
  }
};

handler.help = ['backup'];
handler.tags = ['utility'];
handler.command = ['backup'];
handler.rowner = true;
export default handler;