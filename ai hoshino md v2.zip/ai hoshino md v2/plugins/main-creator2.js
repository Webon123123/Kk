let handler = async (m, { conn }) => {
    // Mensaje decorado inicial
    const mensaje = `
╭───✦ *🌸 Advertencia 🌸* ✦───╮
│  
│  Parece que mencionaste el nombre de 
│  mi creadora. No la menciones para  
│  cosas triviales o *serás bloqueado*.  
│  
╰───────────────────────╯
`.trim();

    // Enviar el mensaje decorado
    await conn.reply(m.chat, mensaje, m);

    // Esperar un segundo antes de enviar el contacto
    await new Promise(resolve => setTimeout(resolve, 1000));

    // VCard del contacto
    let vcard = `BEGIN:VCARD
VERSION:3.0
N:;Ai hoshino⁩;;;
FN:Ai hoshino
ORG:Ai hoshino
TITLE:
item1.TEL;waid=595976230899:595976230899
item1.X-ABLabel:Ai hoshino
X-WA-BIZ-DESCRIPTION:
X-WA-BIZ-NAME:Ai hoshino⁩
END:VCARD`;

    await conn.sendMessage(
        m.chat,
        { contacts: { displayName: 'Ai hoshino developer', contacts: [{ vcard }] } },
        { quoted: m }
    );
};

// Prefijo personalizado para activar el comando
handler.customPrefix = /^(Masha|Kujou)$/i;

// El comando queda vacío ya que solo responde al prefijo
handler.command = new RegExp();

export default handler;