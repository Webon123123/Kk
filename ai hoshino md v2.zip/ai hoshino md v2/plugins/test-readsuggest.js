import fs from 'fs';
import path from 'path';

let handler = async (m, { conn: star }) => {
  let suggestionsFile = path.join('./', 'suggestions.json');
  
  if (!fs.existsSync(suggestionsFile)) return m.reply('> ✐ No hay sugerencias guardadas.');

  let suggestionsData = JSON.parse(fs.readFileSync(suggestionsFile, 'utf-8'));

  if (Object.keys(suggestionsData).length === 0) {
    return m.reply('> ✐ No hay sugerencias guardadas.');
  }

  let response = '> ✐ *Sugerencias guardadas:*\n\n';
  
  for (let category in suggestionsData) {
    response += `*${category}:*\n`;
    suggestionsData[category].forEach((suggestion, index) => {
      response += `  ${index + 1}. ${suggestion} (Enviada por: *${m.pushName}*)\n`;
    });
    response += '\n';
  }

  await star.reply(m.chat, response, m);
};

handler.command = ['viewsuggest', 'sugerencias'];
handler.rowner = true;
export default handler;