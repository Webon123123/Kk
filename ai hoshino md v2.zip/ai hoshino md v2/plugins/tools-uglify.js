import UglifyJS from 'uglify-js';
import { v4 as _0x47c5 } from 'uuid';
import fs from 'fs';
import path from 'path';

let handler = async (m, { text, usedPrefix, command, conn: star }) => {
    try {
        if (!text) {
            return star.reply(m.chat, `「✦」Error: *No ingresaste código o archivo.*\n\n> ✐ *Por favor, ingresa el código que deseas procesar o sube un archivo.*`, m);
        }

        const isFile = text.startsWith('file://');
        let code = text;

        if (isFile) {
            const filePath = text.replace('file://', '');
            if (!fs.existsSync(filePath)) {
                return star.reply(m.chat, `Error: *El archivo no existe en la ruta especificada.*`, m);
            }
            code = fs.readFileSync(filePath, 'utf-8');
        }

        if (command === 'desofuscar') {
            const result = UglifyJS.minify(code, { fromString: true });
            if (result.error) {
                return m.reply('Hubo un error al desofuscar el código.');
            }
            const desofuscado = result.code;
            const formattedCode = UglifyJS.minify(desofuscado, { output: { beautify: true } }).code;

            m.reply(`Código desofuscado:\n\n\`\`\`js\n${formattedCode}\n\`\`\``);
        } else if (command === 'ofuscar') {
            const result = UglifyJS.minify(code, { fromString: true });
            if (result.error) {
                return m.reply('Hubo un error al ofuscar el código.');
            }
            const ofuscado = result.code;

            m.reply(`Código ofuscado:\n\n\`\`\`js\n${ofuscado}\n\`\`\``);
        } else if (command === 'procesar') {
            const fileId = _0x47c5();
            const tmpFile = path.join(__dirname, `${fileId}.js`);
            fs.writeFileSync(tmpFile, code);

            const result = UglifyJS.minify(tmpFile, { fromString: true });
            if (result.error) {
                return m.reply('Hubo un error al procesar el archivo.');
            }

            fs.unlinkSync(tmpFile);

            const processedCode = result.code;
            m.reply(`Código procesado:\n\n\`\`\`js\n${processedCode}\n\`\`\``);
        } else {
            m.reply(`Comando no reconocido. Usa *${usedPrefix}ofuscar*, *${usedPrefix}desofuscar* o *${usedPrefix}procesar*.`);
        }
    } catch (error) {
        console.error(error);
        m.reply('Hubo un problema procesando el código.');
    }
};

handler.help = ['ofuscar', 'desofuscar', 'procesar'];
handler.tags = ['utilidades'];
handler.command = ['ofuscar', 'desofuscar', 'procesar'];

export default handler;