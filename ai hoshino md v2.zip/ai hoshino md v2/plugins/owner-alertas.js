const prefijosPermitidos = ['.', '/', '#', '$', '>']; // Lista de prefijos válidos

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // Verifica si el prefijo usado está en la lista
    if (!prefijosPermitidos.includes(usedPrefix)) return; // Si no, ignora el mensaje

    try {
        // Aquí puedes ejecutar cualquier lógica normal del bot
        m.reply(`✅ Comando con prefijo válido detectado: *${usedPrefix}${command}*`);

        // Simula un error (opcional, para prueba)
        if (command === 'pruebaerror') {
            throw new Error('💥 Este es un error de prueba generado por el usuario.');
        }
    } catch (err) {
        // Capturamos cualquier error y lo reportamos

        let errorMessage = `🔴 *Error Detectado al Ejecutar un Comando*\n\n` +
                           `📌 *Prefijo:* ${usedPrefix}\n` +
                           `📌 *Comando:* ${command}\n\n` +
                           `📂 *Mensaje del Error:*\n\`\`\`${err.message}\`\`\`\n\n` +
                           `📂 *Stack Trace:*\n\`\`\`${err.stack}\`\`\``;

        // Enviar el mensaje al número privado configurado
        const privateChat = '+59162048526@s.whatsapp.net';
        await conn.sendMessage(privateChat, { text: errorMessage });

        // Notificar al usuario que hubo un error
        m.reply('🔴 Se detectó un error y se envió a tu número privado.');
    }
};

handler.all = async (m) => {
    // Esto se ejecuta en TODOS los mensajes con prefijos permitidos
    const prefix = m.text.charAt(0);
    if (!prefijosPermitidos.includes(prefix)) return; // Ignora si no es prefijo válido

    try {
        // Lógica aquí para manejar mensajes genéricos
        // Por ejemplo, si envían `> código`, puedes procesarlo como un evaluador
        if (prefix === '>') eval(m.text.slice(1)); // Intenta evaluar código con `>`
    } catch (err) {
        // Captura errores del evaluador o comandos dinámicos
        let errorMessage = `🔴 *Error Detectado al Ejecutar Evaluador o Prefijo Dinámico*\n\n` +
                           `📌 *Prefijo:* ${prefix}\n\n` +
                           `📂 *Mensaje del Error:*\n\`\`\`${err.message}\`\`\`\n\n` +
                           `📂 *Stack Trace:*\n\`\`\`${err.stack}\`\`\``;

        const privateChat = '+59162048526@s.whatsapp.net';
        await conn.sendMessage(privateChat, { text: errorMessage });
    }
};

handler.customPrefix = /^[./#$>]/; // Detecta cualquier mensaje que empiece con estos prefijos
handler.command = new RegExp; // Se ejecutará para cualquier texto con prefijos

module.exports = handler;