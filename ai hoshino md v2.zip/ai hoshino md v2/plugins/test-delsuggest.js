import fs from 'fs';
import path from 'path';

let handler = async (m, { conn: star, text }) => {
  if (!text) return m.reply('> Formato incorrecto\n\n> ✐ Usa: *.delsuggest <categorías>*');
  
  let categoriesToDelete = text.split(',').map((v) => v.trim());
  if (categoriesToDelete.length === 0) return m.reply('\n\n> ✐ Debes especificar al menos una categoría.');

  let suggestionsFile = path.join('./', 'suggestions.json');
  
  if (!fs.existsSync(suggestionsFile)) return m.reply('> ✐ No hay sugerencias guardadas.');

  let suggestionsData = JSON.parse(fs.readFileSync(suggestionsFile, 'utf-8'));

  categoriesToDelete.forEach(category => {
    if (suggestionsData[category]) {
      delete suggestionsData[category];
    }
  });

  fs.writeFileSync(suggestionsFile, JSON.stringify(suggestionsData, null, 2), 'utf-8');

  await star.reply(m.chat, `> ✐ Categorías eliminadas: *${categoriesToDelete.join(', ')}*`, m);
};

handler.command = ['delsuggest'];
handler.rowner = true;
export default handler;