import fs from 'fs';

// Leer el archivo JSON
function obtenerPersonajes() {
    return JSON.parse(fs.readFileSync('./plugins/personajes.json', 'utf-8'));
}

// Guardar cambios en el archivo JSON
function guardarPersonajes(data) {
    fs.writeFileSync('./plugins/personajes.json', JSON.stringify(data, null, 2));
}

// Objeto temporal para almacenar el personaje seleccionado por cada usuario
let personajesSeleccionados = {};

let handler = async (m, { conn, command }) => {
    let personajes = obtenerPersonajes();

    if (command === 'prueba1') {
        // Filtrar personajes no reclamados
        let personajesNoReclamados = personajes.filter(p => !p.reclamado);

        // Verificar si hay personajes no reclamados disponibles
        if (personajesNoReclamados.length === 0) {
            return conn.reply(m.chat, '⚠️ Todos los personajes ya han sido reclamados.', m);
        }

        // Seleccionar un personaje no reclamado al azar
        let personaje = personajesNoReclamados[Math.floor(Math.random() * personajesNoReclamados.length)];

        // Guardar el personaje seleccionado temporalmente para el usuario
        personajesSeleccionados[m.sender] = {
            personaje: personaje,
            mensajeID: m.id  // Guardamos el ID del mensaje para verificar en `.prueba2`
        };

        let mensaje = `🎲 *Personaje seleccionado*: ${personaje.nombre}\n🧬 *Género*: ${personaje.genero}\n💰 *Valor*: ${personaje.valor}\n\nPara reclamarlo responde a este mensaje con *.prueba2*`;
        
        // Enviar el mensaje del personaje y almacenar el ID del mensaje
        let sentMessage = await conn.reply(m.chat, mensaje, m);
        personajesSeleccionados[m.sender].mensajeID = sentMessage.id;  // Guardamos el ID del mensaje enviado

    } else if (command === 'prueba2') {
        // Verificar si el usuario tiene un personaje seleccionado y si está respondiendo al mensaje correcto
        let seleccionado = personajesSeleccionados[m.sender];
        
        // Verificar si el mensaje respondido es el mensaje del bot con el personaje seleccionado
        if (!seleccionado || !m.quoted || m.quoted.id !== seleccionado.mensajeID) {
            return conn.reply(m.chat, '⚠️ Debes responder al mensaje del personaje que seleccionaste con *.prueba1*.', m);
        }

        let personaje = seleccionado.personaje;

        // Verificar si el personaje ya ha sido reclamado (doble comprobación)
        if (personaje.reclamado) {
            conn.reply(m.chat, `⚠️ El personaje *${personaje.nombre}* ya fue reclamado. Intenta con otro.`, m);
        } else {
            // Reclamar el personaje y guardar el ID del usuario que lo reclamó
            personaje.reclamado = true;
            personaje.reclamadoPor = m.sender;
            guardarPersonajes(personajes);

            // Eliminar el personaje de la lista temporal para evitar reclamos duplicados
            delete personajesSeleccionados[m.sender];

            let mensaje = `🎉 ¡Has reclamado a *${personaje.nombre}*!\n📜 *Género*: ${personaje.genero}\n💰 *Valor*: ${personaje.valor}`;
            conn.reply(m.chat, mensaje, m);
        }
    }
}

handler.command = /^(prueba1|prueba2)$/i;

export default handler;