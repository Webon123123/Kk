import fs from 'fs';
import path from 'path';
import natural from 'natural';

const learningFile = path.join(process.cwd(), 'learning.txt');
const classifier = new natural.BayesClassifier();

if (!fs.existsSync(learningFile)) fs.writeFileSync(learningFile, '');
else {
  const data = fs.readFileSync(learningFile, 'utf-8').split('\n').filter(Boolean);
  for (const line of data) {
    const [input, response] = line.split('|');
    classifier.addDocument(input.trim(), response.trim());
  }
  classifier.train();
}

let handler = async (m, { text, args, command, conn: star }) => {
  if (command === 'iachat') {
    const input = text.trim();
    if (!input) return star.reply(m.chat, 'Por favor, escribe algo para interactuar.', m);

    const response = classifier.classify(input);
    if (!response) return star.reply(m.chat, 'No tengo una respuesta para esto. Enséñame usando: .iachat enseñar | input | respuesta.', m);

    await star.reply(m.chat, response, m);
  } else if (command === 'iachatenseñar') {
    const teachingData = text.split('|').map(s => s.trim());
    if (teachingData.length !== 2) return star.reply(m.chat, 'Formato incorrecto. Usa: .iachat enseñar | input | respuesta.', m);

    const [input, response] = teachingData;
    classifier.addDocument(input, response);
    classifier.train();
    fs.appendFileSync(learningFile, `${input}|${response}\n`);
    await star.reply(m.chat, `Gracias, aprendí que cuando alguien dice "${input}", debo responder "${response}".`, m);
  }
};

handler.help = ['iachat <texto>', 'iachatenseñar | <input> | <respuesta>'];
handler.tags = ['ai'];
handler.command = ['iachat', 'iachatenseñar'];

export default handler;