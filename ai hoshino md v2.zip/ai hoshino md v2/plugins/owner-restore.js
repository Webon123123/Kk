import fs from 'fs';
import path from 'path';
import unzipper from 'unzipper';

let handler = async (m, { conn: star }) => {
  try {
    let backupFolder = './';
    let archiveFileName = 'backup.archive';
    let archiveFilePath = path.join(backupFolder, archiveFileName);

    if (!fs.existsSync(archiveFilePath)) {
      await m.react('✖️');
      return star.reply(m.chat, 'No se encontró ningún archivo de respaldo para restaurar.', m);
    }

    let restoredFiles = [];
    let skippedFiles = [];

    await m.react('⌛');

    fs.createReadStream(archiveFilePath)
      .pipe(unzipper.Parse())
      .on('entry', (entry) => {
        let filePath = path.join(backupFolder, entry.path);
        if (fs.existsSync(filePath)) {
          skippedFiles.push(entry.path);
          entry.autodrain();
        } else {
          entry.pipe(fs.createWriteStream(filePath));
          restoredFiles.push(entry.path);
        }
      })
      .on('close', async () => {
        let message = '📦 *Restauración completada*\n\n';
        if (restoredFiles.length > 0) {
          message += `> ✐ Archivos restaurados:\n- ${restoredFiles.join('\n- ')}\n`;
        }
        if (skippedFiles.length > 0) {
          message += `\n> ✐ Archivos existentes (no modificados):\n- ${skippedFiles.join('\n- ')}`;
        }
        await star.sendMessage(m.chat, { text: message }, { quoted: m });
        await m.react('✅');
      });
  } catch (error) {
    await m.react('✖️');
    await star.reply(m.chat, `Error al restaurar: "${error.message}"`, m);
  }
};

handler.help = ['restore'];
handler.tags = ['utility'];
handler.command = ['restore'];
handler.rowner = true
export default handler;