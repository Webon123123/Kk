import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import Esprima from 'esprima';
import JSHint from 'jshint';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return await m.reply(`「✦」Error: *No ingresaste ningún código para analizar.*\n\n> ✐ Usa el comando así:\n> *${usedPrefix + command}* <código>`);
  }

  const fileName = 'code.js';
  const filePath = path.join('/tmp', fileName);
  fs.writeFileSync(filePath, text);

  let errors = '';
  let suggestions = '';
  let fixedCode = text;

  try {
    Esprima.parseScript(text);

    if (!JSHint.JSHINT(text)) {
      JSHint.JSHINT.errors.forEach((err) => {
        if (err) {
          errors += `🛑 Error en la línea ${err.line}:\n> ✐ *${err.reason}*\n\n`;
          suggestions += generateSuggestion(err.reason, err.line);
        }
      });
    }

    const pluginIssues = detectPluginIssues(text);
    if (pluginIssues.length > 0) {
      pluginIssues.forEach((issue) => {
        errors += `🛠️ Problema con Plugin:\n> ✐ ${issue}\n\n`;
        suggestions += generateSuggestion(issue, null);
      });
    }

    const detailedAnalysis = analyzeCode(text);
    if (detailedAnalysis.errors) {
      errors += detailedAnalysis.errors;
      suggestions += detailedAnalysis.suggestions;
    }

    if (errors) {
      fixedCode = applyFixes(text, suggestions);

      await m.reply(`「✦」*Se encontraron problemas en tu código JavaScript:*\n\n${errors}`);

      const fixedFileName = 'fixed_code.js';
      const fixedFilePath = path.join('/tmp', fixedFileName);
      fs.writeFileSync(fixedFilePath, fixedCode);

      await conn.sendFile(m.chat, fixedFilePath, fixedFileName, `「✦」Aquí tienes el archivo corregido basado en las sugerencias:\n\nPosible solución:\n\n${suggestions}`, m);

      fs.unlinkSync(fixedFilePath);
    } else {
      await m.reply('「✦」¡El código está libre de errores! 🎉');
    }
  } catch (error) {
    errors += `🛑 *Error en la estructura del código:*\n> ✐ *Detalles: ${error.message}*\n\n`;
    suggestions += generateSuggestion(error.message, null);

    await m.reply(`「✦」*Errores detectados:*\n\n${errors}`);

    const fixedFileName = 'fixed_code.js';
    const fixedFilePath = path.join('/tmp', fixedFileName);
    fs.writeFileSync(fixedFilePath, fixedCode);

    const iaResponse = `「✦」*Sugerencias para solucionar los problemas:*\n\nPosible solución:\n\n${suggestions}`;
    await conn.sendFile(m.chat, fixedFilePath, fixedFileName, iaResponse, m);

    fs.unlinkSync(fixedFilePath);
  } finally {
    fs.unlinkSync(filePath);
  }
};

function detectPluginIssues(code) {
  let issues = [];

  if (/var\s+\w+[^=]/.test(code)) {
    issues.push('Variable declarada con var sin inicializar.');
  }

  if (/function\s+\w+/.test(code) && !code.includes('return')) {
    issues.push('Función definida sin un valor de retorno.');
  }

  if (/eval/.test(code)) {
    issues.push('Uso de "eval()", lo cual es inseguro.');
  }

  if (!/require\s*\s*['"][\w-/]+['"]\s*/.test(code) && /require/.test(code)) {
    issues.push('Dependencias requeridas incorrectamente o faltantes.');
  }

  if (/case\s+.*?:\s*(?!break;)/.test(code)) {
    issues.push('Falta un "break" en el bloque case de un switch.');
  }

  return issues;
}

function analyzeCode(code) {
  const lines = code.split('\n');
  let errors = '';
  let suggestions = '';

  lines.forEach((line, index) => {
    if (/let\s+\w+;/.test(line) || /const\s+\w+;/.test(line)) {
      errors += `🔍 Línea ${index + 1}: Declaración de variable sin asignación inicial.\n`;
      suggestions += `✎ Línea ${index + 1}: Asigna un valor inicial a la variable o usa "null" como valor por defecto.\n\n`;
    }

    if (/function\s+\w+/.test(line) && !line.includes('{')) {
      errors += `🔍 Línea ${index + 1}: Definición incompleta de función.\n`;
      suggestions += `✎ Línea ${index + 1}: Asegúrate de incluir el cuerpo de la función con {}.\n\n`;
    }

    if (/case\s+.*?:\s*(?!break;)/.test(line)) {
      errors += `⚠️ Línea ${index + 1}: Falta un "break" en el bloque case.\n`;
      suggestions += `✎ Línea ${index + 1}: Agrega un "break" para evitar que los siguientes bloques se ejecuten accidentalmente.\n\n`;
    }
  });

  return { errors, suggestions };
}

function generateSuggestion(error, line) {
  let suggestion = '';

  if (error.includes('var')) {
    suggestion += `✐ Línea ${line || 'desconocida'}: Reemplaza "var" con "let" o "const" para un mejor manejo de variables.\n\n`;
  }
  if (error.includes('break')) {
    suggestion += `✐ Línea ${line || 'desconocida'}: Asegúrate de incluir "break" en cada bloque case para evitar errores de flujo.\n\n`;
  }
  if (error.includes('eval')) {
    suggestion += `✐ Línea ${line || 'desconocida'}: Evita usar "eval". Busca alternativas más seguras para evaluar expresiones dinámicas.\n\n`;
  }
  if (error.includes('return')) {
    suggestion += `✐ Línea ${line || 'desconocida'}: Agrega un valor de retorno explícito en tu función si es necesario.\n\n`;
  }

  return suggestion;
}

function applyFixes(code, suggestions) {
  let fixedCode = code;

  fixedCode = fixedCode.replace(/var\s/g, 'let ');
  fixedCode = fixedCode.replace(/eval(.*?)/g, '/* eval eliminado */');

  return fixedCode;
}

handler.help = ['iacode'];
handler.tags = ['utility'];
handler.command = ['iacode'];

export default handler;