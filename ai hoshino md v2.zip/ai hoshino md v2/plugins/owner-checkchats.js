import fs from 'fs';
import path from 'path';

let handler = async (m, { conn: star, args, command }) => {
  try {
    if (!args[0]) {
      await m.react('✖️');
      return star.reply(m.chat, `「✦」Error: *No ingresaste un número, ID o enlace válido.*\n\n> ✐ Usa el comando así:\n> *${command}* 51969478611\n> *${command}* https://chat.whatsapp.com/XXXXX`, m);
    }

    let chatId;
    if (args[0].startsWith('https://chat.whatsapp.com/')) {
      let inviteCode = args[0].split('/').pop();
      let groupInfo = await star.groupAcceptInvite(inviteCode).catch(() => null);
      if (!groupInfo) {
        await m.react('✖️');
        return star.reply(m.chat, '「✦」Error: *El enlace del grupo no es válido o ya estás en el grupo.*', m);
      }
      chatId = groupInfo.id;
    } else {
      chatId = args[0].endsWith('@g.us') || args[0].endsWith('@s.whatsapp.net') ? args[0] : args[0] + '@s.whatsapp.net';
    }

    const messages = [];
    const batchSize = 50; // Número de mensajes a cargar en cada iteración
    let cursor = null;

    while (true) {
      const result = await star.loadMessages(chatId, batchSize, { id: cursor }).catch(() => null);
      if (!result || result.length === 0) break;
      messages.push(...result);
      cursor = result[result.length - 1].key.id; // Actualiza el cursor
      if (result.length < batchSize) break; // Si el lote tiene menos mensajes, no hay más mensajes por cargar
    }

    if (messages.length === 0) {
      await m.react('✖️');
      return star.reply(m.chat, `「✦」Error: *El chat con ID ${args[0]} no tiene mensajes o no es válido.*`, m);
    }

    const data = messages.map((msg) => ({
      id: msg.key.id,
      fromMe: msg.key.fromMe,
      message: msg.message?.conversation || msg.message?.extendedTextMessage?.text || 'Archivo/Sticker/Multimedia',
      response: msg.key.fromMe ? 'Enviado por el bot' : 'Enviado por el usuario',
    }));

    const fileName = `chat_${chatId.replace('@g.us', '').replace('@s.whatsapp.net', '')}.json`;
    const filePath = path.join('/tmp', fileName);

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

    await star.sendMessage(
      m.chat,
      {
        document: { url: filePath },
        fileName: fileName,
        mimetype: 'application/json',
        caption: `📂 *Chat exportado con éxito*\n\n> ✐ *ID del Chat:* ${chatId}\n> ✐ *Mensajes Exportados:* ${data.length}`,
      },
      { quoted: m }
    );

    fs.unlinkSync(filePath);
    await m.react('✅');
  } catch (error) {
    await m.react('✖️');
    await star.reply(m.chat, `Error al exportar el chat: "${error.message}"`, m);
  }
};

handler.help = ['checkchat <id/chat-link>'];
handler.tags = ['utility'];
handler.command = ['checkchat'];

export default handler;