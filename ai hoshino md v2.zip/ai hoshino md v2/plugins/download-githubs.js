const fetch = require('node-fetch');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');

const handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`Uso: ${usedPrefix + command} <URL del repositorio GitHub>\n\nEjemplo:\n${usedPrefix + command} https://github.com/usuario/repositorio`);
    }

    // Validar y formatear la URL
    const repoMatch = text.match(/https:\/\/github\.com\/([^\/]+)\/([^\/]+)/);
    if (!repoMatch) {
        return m.reply('Por favor, ingresa una URL válida de un repositorio público de GitHub.');
    }

    const owner = repoMatch[1];
    const repo = repoMatch[2];
    const zipUrl = `https://github.com/${owner}/${repo}/archive/refs/heads/main.zip`; // Cambiar "main" si el repositorio usa otro branch.

    try {
        // Descarga el archivo .zip
        m.reply('Descargando el repositorio...');
        const response = await fetch(zipUrl);
        if (!response.ok) throw new Error('No se pudo descargar el archivo. Verifica la URL del repositorio.');

        const buffer = await response.buffer();
        const zipPath = path.join(__dirname, `${repo}.zip`);
        fs.writeFileSync(zipPath, buffer);

        // Extraer el archivo
        m.reply('Extrayendo el contenido del archivo...');
        const zip = new AdmZip(zipPath);
        const extractPath = path.join(__dirname, repo);
        zip.extractAllTo(extractPath, true);

        // Eliminar el archivo .zip después de extraer
        fs.unlinkSync(zipPath);

        m.reply(`Repositorio descargado y extraído exitosamente en: ${extractPath}`);
    } catch (err) {
        console.error(err);
        m.reply('Ocurrió un error durante la descarga o extracción. Verifica que el repositorio sea público y la URL sea correcta.');
    }
};

handler.command = ['descargarrepo']; // Comando que activará este plugin

module.exports = handler;