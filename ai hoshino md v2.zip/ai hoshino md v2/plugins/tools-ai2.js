import Starlights from '@StarlightsTeam/Scraper'
import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      `*🚩 Ingrese su petición*\n\n🪼 *Ejemplo de uso:*\n${usedPrefix + command} ¿Cómo escribir una historia creativa?`,
      m
    )
  }

  await m.react('🤖')

  // Función para dividir texto largo
  const dividirTexto = (texto, maxLength = 4096) => {
    let partes = [];
    while (texto.length > maxLength) {
      let corte = texto.lastIndexOf('\n', maxLength);
      if (corte === -1) corte = maxLength;
      partes.push(texto.slice(0, corte));
      texto = texto.slice(corte);
    }
    partes.push(texto);
    return partes;
  };

  // Decoración del mensaje
  const decorarMensaje = (titulo, contenido) => {
    return `╭─── *🤖 Respuesta de la IA*\n│\n│ *💡 ${titulo}:*\n│ ${contenido.replace(/\n/g, '\n│ ')}\n╰───────────`;
  };

  try {
    let { msg } = await Starlights.openAi(text);
    let partes = dividirTexto(msg);
    for (let parte of partes) {
      await conn.reply(m.chat, decorarMensaje('Respuesta', parte), m);
    }
  } catch {
    try {
      let { result } = await Starlights.ChatGpt(text);
      let partes = dividirTexto(result);
      for (let parte of partes) {
        await conn.reply(m.chat, decorarMensaje('Respuesta Alternativa', parte), m);
      }
    } catch {
      try {
        let { result } = await Starlights.ChatGptV2(text);
        let partes = dividirTexto(result);
        for (let parte of partes) {
          await conn.reply(m.chat, decorarMensaje('Respuesta Alternativa 2', parte), m);
        }
      } catch {
        try {
          let api = await fetch(`https://apis-starlights-team.koyeb.app/starlight/chatgpt?text=${encodeURIComponent(text)}`);
          let json = await api.json();
          if (json.result) {
            let partes = dividirTexto(json.result);
            for (let parte of partes) {
              await conn.reply(m.chat, decorarMensaje('Respuesta de Emergencia', parte), m);
            }
          } else {
            await m.react('✖️');
          }
        } catch {
          await m.react('✖️');
        }
      }
    }
  }
};

handler.help = ['ai *<petición>*'];
handler.tags = ['tools'];
handler.command = /^(miku|ai|ia|chatgpt|gpt|inteligencia-artificial)$/i;
handler.register = true;

export default handler;