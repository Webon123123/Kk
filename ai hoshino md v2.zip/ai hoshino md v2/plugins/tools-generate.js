import fetch from 'node-fetch';

let handler = async (m, { conn, command, args }) => {
    if (command === 'crearimagen') {
        const texto = args.join(" ");
        if (!texto) return conn.reply(m.chat, "⚠️ Necesitas proporcionar un texto para generar la imagen.", m);

        try {
            // Realizar solicitud a la API de Craiyon
            const response = await fetch(`https://api.craiyon.com/generate?prompt=${encodeURIComponent(texto)}`);
            const data = await response.json();

            if (data?.images?.length > 0) {
                const imgSrc = data.images[0]; // Obtén la primera imagen generada
                conn.reply(m.chat, `Aquí está la imagen que generé: ${imgSrc}`, m);
            } else {
                conn.reply(m.chat, "⚠️ No se pudo generar la imagen.", m);
            }
        } catch (err) {
            console.error("Error al generar la imagen:", err);
            conn.reply(m.chat, `⚠️ Error inesperado: ${err.message}`, m);
        }
    }
};

handler.command = /^(crearimagen)$/i;

export default handler;