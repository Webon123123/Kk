import fs from 'fs';
import path from 'path';

let handler = async (m, { conn: star, command }) => {
  try {
    if (!m.quoted) {
      await m.react('✖️');
      return star.reply(m.chat, `「✦」Error: *Por favor, responde a un mensaje para obtener la ID.*`, m);
    }

    // Obtener el mensaje original al que se responde
    const quotedMessage = m.quoted;
    const messageId = quotedMessage.key.id;

    // Crear objeto JSON con los detalles del mensaje y la respuesta
    const messageData = {
      messageId: messageId,
      originalMessage: quotedMessage.message?.conversation || quotedMessage.message?.extendedTextMessage?.text || 'Archivo/Sticker/Multimedia',
      response: m.text,
      responderId: m.sender
    };

    const fileName = `message_response_${messageId}.json`;
    const filePath = path.join('/tmp', fileName);

    // Escribir el objeto en un archivo JSON
    fs.writeFileSync(filePath, JSON.stringify(messageData, null, 2));

    // Enviar el archivo JSON al chat
    await star.sendMessage(
      m.chat,
      {
        document: { url: filePath },
        fileName: fileName,
        mimetype: 'application/json',
        caption: `📂 *Respuesta al mensaje exportada con éxito*\n\n> ✐ *Mensaje ID:* ${messageId}`,
      },
      { quoted: m }
    );

    fs.unlinkSync(filePath); // Eliminar el archivo temporal después de enviarlo
    await m.react('✅');
  } catch (error) {
    await m.react('✖️');
    await star.reply(m.chat, `Error al obtener la respuesta: "${error.message}"`, m);
  }
};

handler.help = ['getresponse'];
handler.tags = ['utility'];
handler.command = ['getresponse'];

export default handler;