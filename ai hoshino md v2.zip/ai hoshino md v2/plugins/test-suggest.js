import fs from 'fs';
import path from 'path';

let handler = async (m, { conn: star, text }) => {
  if (!text.includes('|')) return m.reply('> Formato incorrecto\n\n> ✐ Usa: *.suggest <categoría> | <sugerencia>*');
  
  let [category, suggestion] = text.split('|').map((v) => v.trim());
  if (!category || !suggestion) return m.reply('\n\n> ✐ Debes especificar una categoría y una sugerencia.');

  let suggestionsFile = path.join('./', 'suggestions.json');
  
  if (!fs.existsSync(suggestionsFile)) {
    fs.writeFileSync(suggestionsFile, JSON.stringify({}), 'utf-8');
  }

  let suggestionsData = JSON.parse(fs.readFileSync(suggestionsFile, 'utf-8'));

  if (!suggestionsData[category]) {
    suggestionsData[category] = [];
  }

  suggestionsData[category].push(suggestion);

  fs.writeFileSync(suggestionsFile, JSON.stringify(suggestionsData, null, 2), 'utf-8');

  await star.reply(m.chat, `> ✐ Sugerencia añadida bajo la categoría *${category}*`, m);
};

handler.command = ['suggest'];
handler.private = true;
export default handler;