import crypto from 'crypto'
import fs from 'fs'
import path from 'path'

const algorithm = 'aes-256-cbc'
const key = crypto.randomBytes(32)
const iv = crypto.randomBytes(16)

function encrypt(text) {
    let cipher = crypto.createCipheriv(algorithm, Buffer.from(key), iv)
    let encrypted = cipher.update(text)
    encrypted = Buffer.concat([encrypted, cipher.final()])
    return `${iv.toString('hex')}:${encrypted.toString('hex')}`
}

function decrypt(text) {
    let textParts = text.split(':')
    let iv = Buffer.from(textParts.shift(), 'hex')
    let encryptedText = Buffer.from(textParts.join(':'), 'hex')
    let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), iv)
    let decrypted = decipher.update(encryptedText)
    decrypted = Buffer.concat([decrypted, decipher.final()])
    return decrypted.toString()
}

async function encryptHandler(m, { text, isOwner }) {
    if (!isOwner) return m.reply('Este comando es solo para los owners del bot.')
    if (!text) return m.reply('Por favor, proporciona el texto a encriptar después del comando.')

    const encryptedText = encrypt(text)
    const fileName = 'nombre.txt'
    const filePath = path.join('/tmp', fileName)
    
    fs.writeFileSync(filePath, encryptedText, 'utf8')
    
    await conn.sendMessage(m.chat, { document: { url: filePath }, mimetype: 'text/plain', fileName })
    
    fs.unlinkSync(filePath)
}

async function decryptHandler(m, { text, isOwner }) {
    if (!isOwner) return m.reply('Este comando es solo para los owners del bot.')
    if (!text) return m.reply('Por favor, proporciona el texto encriptado después del comando.')
    try {
        const decryptedText = decrypt(text)
        await m.reply(`🔓 Texto desencriptado:\n${decryptedText}`)
    } catch (error) {
        await m.reply('Error: El texto proporcionado no se pudo desencriptar. Asegúrate de que sea el correcto.')
    }
}

let handler = async (m, { command, text, isOwner }) => {
    if (command === 'encrypt') await encryptHandler(m, { text, isOwner })
    if (command === 'decrypt') await decryptHandler(m, { text, isOwner })
}

handler.help = ['encrypt <texto>', 'decrypt <texto_cifrado>']
handler.tags = ['tools']
handler.command = /^(encrypt|decrypt)$/i
handler.rowner = true

export default handler